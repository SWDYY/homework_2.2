package GUI;

public class Statistics {

}
